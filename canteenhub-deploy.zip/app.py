import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from datetime import datetime
import json

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your-secret-key-here')

# Use environment variable for port (cloud platforms set this automatically)
port = int(os.environ.get('PORT', 5000))

# In-memory storage (in production, use a database)
orders = []
menu_items = [
    {"id": 1, "name": "Burger", "price": 8.99, "category": "Main"},
    {"id": 2, "name": "Pizza", "price": 12.99, "category": "Main"},
    {"id": 3, "name": "Salad", "price": 6.99, "category": "Healthy"},
    {"id": 4, "name": "Coffee", "price": 2.99, "category": "Beverage"},
    {"id": 5, "name": "Sandwich", "price": 5.99, "category": "Quick"},
]

@app.route('/')
def index():
    return render_template('index.html', menu_items=menu_items)

@app.route('/menu')
def menu():
    return render_template('menu.html', menu_items=menu_items)

@app.route('/order', methods=['GET', 'POST'])
def order():
    if request.method == 'POST':
        customer_name = request.form.get('customer_name')
        items = request.form.getlist('items')
        
        if customer_name and items:
            order = {
                'id': len(orders) + 1,
                'customer_name': customer_name,
                'items': items,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'pending'
            }
            orders.append(order)
            flash('Order placed successfully!', 'success')
            return redirect(url_for('order_status', order_id=order['id']))
        else:
            flash('Please fill in all fields', 'error')
    
    return render_template('order.html', menu_items=menu_items)

@app.route('/orders')
def view_orders():
    return render_template('orders.html', orders=orders)

@app.route('/order-status/<int:order_id>')
def order_status(order_id):
    order = next((o for o in orders if o['id'] == order_id), None)
    if order:
        return render_template('order_status.html', order=order)
    flash('Order not found', 'error')
    return redirect(url_for('index'))

@app.route('/api/orders')
def api_orders():
    return jsonify(orders)

@app.route('/api/menu')
def api_menu():
    return jsonify(menu_items)

if __name__ == '__main__':
    # Listen on all interfaces (0.0.0.0) for cloud deployment
    app.run(host='0.0.0.0', port=port, debug=False)
