const CACHE_NAME = 'canteenhub-v1.0.0';
const UPDATE_CHECK_INTERVAL = 30000; // Check for updates every 30 seconds
const CACHE_EXPIRY = 24 * 60 * 60 * 1000; // 24 hours

// Files to cache for offline functionality
const STATIC_CACHE_FILES = [
  '/',
  '/static/style.css',
  '/static/manifest.json',
  '/faculty_login',
  '/admin_login',
  '/canteen_login',
  '/factuality',
  // Add more static assets as needed
];

// Dynamic cache patterns
const DYNAMIC_CACHE_PATTERNS = [
  /^\/order/,
  /^\/admin_dashboard/,
  /^\/canteen_orders/,
  /^\/static\//,
];

// Install event - cache static files
self.addEventListener('install', (event) => {
  console.log('[SW] Installing service worker...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Caching static files');
        return cache.addAll(STATIC_CACHE_FILES);
      })
      .then(() => {
        console.log('[SW] Installation complete');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('[SW] Installation failed:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating service worker...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME) {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[SW] Activation complete');
        return self.clients.claim();
      })
  );
  
  // Start periodic update checks
  startUpdateChecker();
});

// Fetch event - network first with cache fallback
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // Skip Chrome extension requests
  if (url.protocol === 'chrome-extension:') {
    return;
  }
  
  event.respondWith(
    networkFirstStrategy(request)
  );
});

// Network-first strategy with cache fallback
async function networkFirstStrategy(request) {
  const url = new URL(request.url);
  
  try {
    // Try network first
    const networkResponse = await fetch(request);
    
    // If successful, update cache for future use
    if (networkResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      
      // Only cache specific patterns to avoid caching everything
      if (shouldCache(url)) {
        cache.put(request, networkResponse.clone());
      }
      
      return networkResponse;
    }
    
    throw new Error(`Network response not ok: ${networkResponse.status}`);
  } catch (error) {
    console.log('[SW] Network failed, trying cache:', error.message);
    
    // Network failed, try cache
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // If it's a navigation request and no cache, return offline page
    if (request.mode === 'navigate') {
      return createOfflinePage();
    }
    
    // For other requests, return a network error response
    return new Response('Network error occurred', {
      status: 408,
      statusText: 'Network error'
    });
  }
}

// Check if URL should be cached
function shouldCache(url) {
  // Cache static files and specific patterns
  if (STATIC_CACHE_FILES.some(file => url.pathname === file)) {
    return true;
  }
  
  return DYNAMIC_CACHE_PATTERNS.some(pattern => pattern.test(url.pathname));
}

// Create offline fallback page
function createOfflinePage() {
  const offlineHTML = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Offline - CanteenHub</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body { padding-top: 100px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
            .offline-container { max-width: 500px; margin: 0 auto; text-align: center; color: white; }
            .offline-icon { font-size: 4rem; margin-bottom: 2rem; }
            .btn-retry { background: rgba(255,255,255,0.2); border: 2px solid rgba(255,255,255,0.3); color: white; }
            .btn-retry:hover { background: rgba(255,255,255,0.3); color: white; }
        </style>
    </head>
    <body>
        <div class="offline-container">
            <div class="offline-icon">📱</div>
            <h1 class="mb-4">You're Offline</h1>
            <p class="mb-4">It looks like you've lost your internet connection. Don't worry, CanteenHub works offline too!</p>
            <button class="btn btn-retry btn-lg" onclick="window.location.reload()">
                Try Again
            </button>
            <div class="mt-4">
                <small>Some features may be limited while offline</small>
            </div>
        </div>
    </body>
    </html>
  `;
  
  return new Response(offlineHTML, {
    headers: { 'Content-Type': 'text/html' }
  });
}

// Auto-update functionality
function startUpdateChecker() {
  setInterval(async () => {
    try {
      await checkForUpdates();
    } catch (error) {
      console.error('[SW] Update check failed:', error);
    }
  }, UPDATE_CHECK_INTERVAL);
}

async function checkForUpdates() {
  try {
    const response = await fetch('/api/version', { 
      cache: 'no-cache',
      headers: {
        'Cache-Control': 'no-cache'
      }
    });
    
    if (!response.ok) {
      return;
    }
    
    const versionData = await response.json();
    const currentVersion = await getCurrentVersion();
    
    if (versionData.version !== currentVersion) {
      console.log('[SW] New version available:', versionData.version);
      await updateApp(versionData);
    }
  } catch (error) {
    console.log('[SW] Version check failed:', error);
  }
}

async function getCurrentVersion() {
  try {
    const manifestResponse = await caches.match('/static/manifest.json');
    if (manifestResponse) {
      const manifest = await manifestResponse.json();
      return manifest.version;
    }
  } catch (error) {
    console.error('[SW] Could not get current version:', error);
  }
  return '1.0.0';
}

async function updateApp(versionData) {
  try {
    // Clear old caches
    const cacheNames = await caches.keys();
    await Promise.all(
      cacheNames.map(name => caches.delete(name))
    );
    
    // Cache new version
    const cache = await caches.open(`canteenhub-v${versionData.version}`);
    await cache.addAll(STATIC_CACHE_FILES);
    
    // Notify all clients about the update
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
      client.postMessage({
        type: 'APP_UPDATED',
        version: versionData.version,
        message: 'CanteenHub has been updated! Please refresh to see the latest features.'
      });
    });
    
    console.log('[SW] App updated to version:', versionData.version);
  } catch (error) {
    console.error('[SW] Update failed:', error);
  }
}

// Handle messages from main thread
self.addEventListener('message', (event) => {
  const { type, data } = event.data;
  
  switch (type) {
    case 'SKIP_WAITING':
      self.skipWaiting();
      break;
      
    case 'CACHE_URLS':
      if (data.urls && Array.isArray(data.urls)) {
        cacheUrls(data.urls);
      }
      break;
      
    case 'CHECK_UPDATE':
      checkForUpdates();
      break;
  }
});

async function cacheUrls(urls) {
  try {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(urls);
    console.log('[SW] URLs cached successfully');
  } catch (error) {
    console.error('[SW] Failed to cache URLs:', error);
  }
}

// Background sync for offline actions
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync triggered:', event.tag);
  
  if (event.tag === 'order-sync') {
    event.waitUntil(syncPendingOrders());
  }
});

async function syncPendingOrders() {
  // This would sync any pending orders when back online
  // Implementation depends on your offline storage strategy
  console.log('[SW] Syncing pending orders...');
}

// Push notifications for updates (if needed)
self.addEventListener('push', (event) => {
  const options = {
    body: event.data ? event.data.text() : 'CanteenHub has been updated!',
    icon: '/static/icons/icon-192x192.png',
    badge: '/static/icons/icon-72x72.png',
    tag: 'canteenhub-update',
    requireInteraction: true,
    actions: [
      {
        action: 'open',
        title: 'Open App',
        icon: '/static/icons/icon-96x96.png'
      },
      {
        action: 'dismiss',
        title: 'Dismiss'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('CanteenHub', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  if (event.action === 'open' || !event.action) {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});
