// Progressive Web App initialization and management
class PWAManager {
    constructor() {
        this.swRegistration = null;
        this.updateAvailable = false;
        this.deferredPrompt = null;
        
        this.init();
    }
    
    async init() {
        // Register service worker
        if ('serviceWorker' in navigator) {
            try {
                this.swRegistration = await navigator.serviceWorker.register('/static/sw.js', {
                    scope: '/'
                });
                
                console.log('Service Worker registered successfully');
                this.setupUpdateHandling();
                
                // Listen for messages from service worker
                navigator.serviceWorker.addEventListener('message', (event) => {
                    this.handleServiceWorkerMessage(event);
                });
                
            } catch (error) {
                console.error('Service Worker registration failed:', error);
            }
        }
        
        // Setup install prompt
        this.setupInstallPrompt();
        
        // Setup notifications if supported
        this.setupNotifications();
        
        // Check for updates periodically
        this.startUpdateChecker();
    }
    
    setupUpdateHandling() {
        if (!this.swRegistration) return;
        
        // Handle updates
        this.swRegistration.addEventListener('updatefound', () => {
            const newWorker = this.swRegistration.installing;
            
            newWorker.addEventListener('statechange', () => {
                if (newWorker.state === 'installed') {
                    if (navigator.serviceWorker.controller) {
                        // New update available
                        this.updateAvailable = true;
                        this.showUpdateNotification();
                    } else {
                        // First time install
                        console.log('Content is cached for offline use.');
                        this.showInstallSuccess();
                    }
                }
            });
        });
        
        // Handle controlling service worker change
        navigator.serviceWorker.addEventListener('controllerchange', () => {
            // Refresh to show new content
            window.location.reload();
        });
    }
    
    setupInstallPrompt() {
        // Capture the install prompt
        window.addEventListener('beforeinstallprompt', (event) => {
            event.preventDefault();
            this.deferredPrompt = event;
            
            // Show custom install button/banner
            this.showInstallPrompt();
        });
        
        // Handle successful app installation
        window.addEventListener('appinstalled', () => {
            console.log('PWA installed successfully');
            this.hideInstallPrompt();
            this.showNotification('CanteenHub installed successfully!', 'success');
            
            // Clear the deferred prompt
            this.deferredPrompt = null;
        });
    }
    
    setupNotifications() {
        // Request notification permission if not already granted
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    console.log('Notification permission granted');
                }
            });
        }
    }
    
    startUpdateChecker() {
        // Check for updates every 5 minutes
        setInterval(() => {
            this.checkForUpdates();
        }, 5 * 60 * 1000);
        
        // Initial check after 30 seconds
        setTimeout(() => {
            this.checkForUpdates();
        }, 30000);
    }
    
    async checkForUpdates() {
        if (this.swRegistration) {
            try {
                await this.swRegistration.update();
            } catch (error) {
                console.log('Update check failed:', error);
            }
        }
    }
    
    handleServiceWorkerMessage(event) {
        const { type, version, message } = event.data;
        
        switch (type) {
            case 'APP_UPDATED':
                this.showUpdateNotification(message, version);
                break;
            default:
                console.log('Unknown message from service worker:', event.data);
        }
    }
    
    showInstallPrompt() {
        // Create install prompt UI
        const installBanner = document.getElementById('pwa-install-banner');
        if (installBanner) {
            installBanner.style.display = 'block';
            return;
        }
        
        // Create install banner if it doesn't exist
        const banner = document.createElement('div');
        banner.id = 'pwa-install-banner';
        banner.className = 'pwa-install-banner';
        banner.innerHTML = `
            <div class="pwa-banner-content">
                <div class="pwa-banner-icon">📱</div>
                <div class="pwa-banner-text">
                    <strong>Install CanteenHub</strong>
                    <p>Get the full app experience with offline access!</p>
                </div>
                <div class="pwa-banner-actions">
                    <button class="btn btn-primary btn-sm" id="pwa-install-btn">Install</button>
                    <button class="btn btn-outline-secondary btn-sm" id="pwa-dismiss-btn">×</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(banner);
        
        // Handle install button click
        document.getElementById('pwa-install-btn').addEventListener('click', () => {
            this.installApp();
        });
        
        // Handle dismiss button click
        document.getElementById('pwa-dismiss-btn').addEventListener('click', () => {
            this.hideInstallPrompt();
        });
    }
    
    hideInstallPrompt() {
        const installBanner = document.getElementById('pwa-install-banner');
        if (installBanner) {
            installBanner.style.display = 'none';
        }
    }
    
    async installApp() {
        if (!this.deferredPrompt) {
            console.log('Install prompt not available');
            return;
        }
        
        try {
            // Show the install prompt
            this.deferredPrompt.prompt();
            
            // Wait for user response
            const result = await this.deferredPrompt.userChoice;
            
            if (result.outcome === 'accepted') {
                console.log('User accepted the install prompt');
            } else {
                console.log('User dismissed the install prompt');
            }
            
            // Clear the deferred prompt
            this.deferredPrompt = null;
            this.hideInstallPrompt();
            
        } catch (error) {
            console.error('Install failed:', error);
        }
    }
    
    showUpdateNotification(message = 'A new version is available!', version = '') {
        // Create update notification
        const notification = document.createElement('div');
        notification.className = 'pwa-update-notification alert alert-info alert-dismissible fade show';
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="pwa-update-icon me-3">🔄</div>
                <div class="flex-grow-1">
                    <strong>Update Available ${version ? `(v${version})` : ''}</strong>
                    <p class="mb-0 small">${message}</p>
                </div>
                <div class="pwa-update-actions ms-3">
                    <button class="btn btn-success btn-sm me-2" onclick="pwaManager.applyUpdate()">Update</button>
                    <button class="btn btn-outline-secondary btn-sm" onclick="this.parentElement.parentElement.parentElement.remove()">Later</button>
                </div>
            </div>
        `;
        
        // Insert at top of main container
        const mainContainer = document.querySelector('main.container') || document.body;
        mainContainer.insertBefore(notification, mainContainer.firstChild);
        
        // Auto-hide after 10 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 10000);
    }
    
    applyUpdate() {
        if (this.swRegistration && this.swRegistration.waiting) {
            // Tell the waiting service worker to take over
            this.swRegistration.waiting.postMessage({ type: 'SKIP_WAITING' });
        } else {
            // Refresh to get the latest version
            window.location.reload();
        }
    }
    
    showInstallSuccess() {
        this.showNotification('CanteenHub is ready for offline use!', 'success');
    }
    
    showNotification(message, type = 'info', duration = 5000) {
        // Create bootstrap alert
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show pwa-notification`;
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Add to notifications container or create one
        let container = document.getElementById('pwa-notifications');
        if (!container) {
            container = document.createElement('div');
            container.id = 'pwa-notifications';
            container.className = 'pwa-notifications-container';
            document.body.appendChild(container);
        }
        
        container.appendChild(alert);
        
        // Auto-remove after duration
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, duration);
        
        // Also show browser notification if permission granted
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('CanteenHub', {
                body: message,
                icon: '/static/icons/icon-192x192.png',
                tag: 'canteenhub-notification'
            });
        }
    }
    
    // Utility methods for app-specific features
    cacheImportantData() {
        // Cache important app data for offline use
        if (this.swRegistration) {
            this.swRegistration.active?.postMessage({
                type: 'CACHE_URLS',
                data: {
                    urls: [
                        '/api/orders',
                        '/api/users',
                        '/api/notices'
                    ]
                }
            });
        }
    }
    
    isOnline() {
        return navigator.onLine;
    }
    
    isStandalone() {
        return window.matchMedia('(display-mode: standalone)').matches ||
               window.navigator.standalone ||
               document.referrer.includes('android-app://');
    }
    
    getInstallPrompt() {
        return this.deferredPrompt;
    }
}

// Global PWA manager instance
const pwaManager = new PWAManager();

// Add online/offline indicators
window.addEventListener('online', () => {
    pwaManager.showNotification('You\'re back online!', 'success', 3000);
});

window.addEventListener('offline', () => {
    pwaManager.showNotification('You\'re offline. Some features may be limited.', 'warning', 5000);
});

// Export for global access
window.pwaManager = pwaManager;
